export const aboutMeData = [
	{
		id: 1,
		bio: 'As a passionate frontend developer, I thrive on crafting seamless and engaging user experiences. With a solid foundation in HTML, CSS, and JavaScript, I have a proven track record of building responsive and visually appealing web applications. My expertise includes leveraging popular frameworks such as React, Angular, or Vue.js to create dynamic interfaces that seamlessly integrate with backend systems. I possess a strong eye for design and a deep understanding of user-centric development, ensuring that every product I work on not only looks great but also offers intuitive and efficient functionality.'},
	{
		id: 2,
		bio: 'Constantly keeping up with the latest trends and best practices in web development, I am dedicated to delivering high-quality, scalable, and performance-optimized solutions. Collaborative by nature, I enjoy working in dynamic teams, brainstorming ideas, and contributing to a creative and innovative work environment.',
	},
];
